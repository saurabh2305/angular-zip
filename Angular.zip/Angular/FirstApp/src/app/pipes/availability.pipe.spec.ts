import { AvailabilityPipe } from './availability.pipe';

describe('AvailabilityPipe', () => {
  it('create an instance', () => {
    const pipe = new AvailabilityPipe();
    expect(pipe).toBeTruthy();
  });
});
