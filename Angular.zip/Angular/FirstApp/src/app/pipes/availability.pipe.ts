import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'availability'
})
export class AvailabilityPipe implements PipeTransform {

  transform(quantity: number): string {
    if(quantity <= 0)
    return "out of stock";
    else
    {
      return "in stock";
    }   
  }
}
