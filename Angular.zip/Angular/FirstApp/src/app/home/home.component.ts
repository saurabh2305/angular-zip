import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  name:string;
  today:Date;
  ismarrired:boolean=true;
  size:number=18;
  colorCode:string="#00000"
  products:any[]=[
    {id:1,name:"Burgar",price:80,quantity:0},
    {id:2,name:"Burgar",price:90,quantity:10},
    {id:3,name:"Burgar",price:100,quantity:10},
    {id:4,name:"Burgar",price:110,quantity:10},
  ];
  constructor() { 
    this.name ="Kedar";
    this.today =new Date();
  }

  ngOnInit() {
    
  }
    
    updateFont(ctrl){
      this.size = ctrl.value;   
  }
  updateColor(ctrl){
    this.colorCode = ctrl.value;
  }

}
